import base64
import io
import json
import os
import threading
from datetime import datetime, timezone

from google.oauth2 import service_account
from google.auth.transport.requests import AuthorizedSession

import app

SCOPES = ['https://www.googleapis.com/auth/drive']
_LOCK = threading.Lock()
_LAST_BACKUP_DATE = None
_FOLDER_CACHE = {}


def _service_info():
    raw = os.environ.get('GOOGLE_SERVICE_ACCOUNT_JSON', '').strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError('GOOGLE_SERVICE_ACCOUNT_JSON is not valid JSON') from exc


def configured():
    return bool(_service_info() and os.environ.get('GOOGLE_DRIVE_FOLDER_ID', '').strip())


def _session():
    info = _service_info()
    if not info:
        raise RuntimeError('Google Drive service account is not configured')
    creds = service_account.Credentials.from_service_account_info(info, scopes=SCOPES)
    return AuthorizedSession(creds)


def _root_folder():
    folder = os.environ.get('GOOGLE_DRIVE_FOLDER_ID', '').strip()
    if not folder:
        raise RuntimeError('GOOGLE_DRIVE_FOLDER_ID is not configured')
    return folder


def _find_or_create_folder(name):
    key = (_root_folder(), name)
    if key in _FOLDER_CACHE:
        return _FOLDER_CACHE[key]
    sess = _session()
    q = "name='%s' and mimeType='application/vnd.google-apps.folder' and '%s' in parents and trashed=false" % (name.replace("'", "\\'"), _root_folder())
    r = sess.get('https://www.googleapis.com/drive/v3/files', params={'q': q, 'fields': 'files(id,name)', 'pageSize': 10}, timeout=30)
    if not r.ok:
        raise RuntimeError('Google Drive folder lookup failed: ' + r.text[:300])
    files = r.json().get('files', [])
    if files:
        folder_id = files[0]['id']
    else:
        r = sess.post('https://www.googleapis.com/drive/v3/files', params={'fields': 'id'}, json={'name': name, 'mimeType': 'application/vnd.google-apps.folder', 'parents': [_root_folder()]}, timeout=30)
        if not r.ok:
            raise RuntimeError('Google Drive folder creation failed: ' + r.text[:300])
        folder_id = r.json()['id']
    _FOLDER_CACHE[key] = folder_id
    return folder_id


def _multipart_upload(name, data, mime_type, folder_name='Documents'):
    if not configured():
        raise RuntimeError('Google Drive is not configured')
    folder_id = _find_or_create_folder(folder_name)
    boundary = 'cdc-boundary-7c9f3f'
    metadata = json.dumps({'name': name, 'parents': [folder_id]}, separators=(',', ':')).encode()
    body = b''.join([
        ('--%s\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' % boundary).encode(), metadata, b'\r\n',
        ('--%s\r\nContent-Type: %s\r\n\r\n' % (boundary, mime_type or 'application/octet-stream')).encode(), data, b'\r\n',
        ('--%s--\r\n' % boundary).encode(),
    ])
    sess = _session()
    r = sess.post('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink', data=body, headers={'Content-Type': 'multipart/related; boundary=%s' % boundary}, timeout=60)
    if not r.ok:
        raise RuntimeError('Google Drive upload failed: ' + r.text[:500])
    return r.json()


def status(handler):
    stored, user = handler.require_user()
    if not stored:
        return
    handler.send_json({'ok': True, 'configured': configured(), 'folderConfigured': bool(os.environ.get('GOOGLE_DRIVE_FOLDER_ID', '').strip()), 'serviceAccountConfigured': bool(os.environ.get('GOOGLE_SERVICE_ACCOUNT_JSON', '').strip()), 'role': user.get('role')})


def upload_from_json(handler, payload):
    stored, user = handler.require_user()
    if not stored:
        return
    try:
        name = str(payload.get('name') or 'document').strip()[:180]
        mime_type = str(payload.get('mimeType') or 'application/octet-stream').strip()[:120]
        data_b64 = str(payload.get('dataBase64') or '')
        if ',' in data_b64 and data_b64.lstrip().startswith('data:'):
            data_b64 = data_b64.split(',', 1)[1]
        data = base64.b64decode(data_b64, validate=True)
        if not data:
            raise ValueError('File is empty')
        if len(data) > 12 * 1024 * 1024:
            raise ValueError('Drive uploads are limited to 12 MB per file on this build')
        result = _multipart_upload(name, data, mime_type, 'Documents')
        handler.send_json({'ok': True, 'file': result})
    except Exception as exc:
        handler.send_json({'error': str(exc)}, 400)


def _backup_payload(state, revision):
    return json.dumps({'product': 'Command de Cuisine', 'revision': revision, 'exportedAt': datetime.now(timezone.utc).isoformat(), 'state': state}, ensure_ascii=False, indent=2).encode('utf-8')


def maybe_daily_backup(state, revision):
    global _LAST_BACKUP_DATE
    if not configured():
        return None
    today = datetime.now(timezone.utc).date().isoformat()
    with _LOCK:
        if _LAST_BACKUP_DATE == today:
            return None
        name = 'command-de-cuisine-%s.json' % today
        result = _multipart_upload(name, _backup_payload(state, revision), 'application/json', 'Backups')
        _LAST_BACKUP_DATE = today
        return result


def backup_now(handler):
    stored, user = handler.require_user()
    if not stored:
        return
    if user.get('role') != 'manager':
        handler.send_json({'error': 'Admin access required.'}, 403)
        return
    try:
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
        result = _multipart_upload('command-de-cuisine-%s.json' % stamp, _backup_payload(stored['state'], stored['revision']), 'application/json', 'Backups')
        handler.send_json({'ok': True, 'file': result})
    except Exception as exc:
        handler.send_json({'error': str(exc)}, 400)
