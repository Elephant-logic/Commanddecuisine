import json
import os
from pathlib import Path
from http.server import ThreadingHTTPServer
import app
import startup_history
import auth_controls
import logout_control
import ai_guard
import paper_import_control
import temperature_recovery_control
import temperature_store
import drive_storage

BASE_DIR = Path(__file__).resolve().parent


def extract_embedded_paperwork():
    text = (BASE_DIR / 'index.html').read_text(encoding='utf-8')
    marker = 'paperwork: ['
    start = text.find(marker)
    if start < 0:
        return []
    start = text.find('[', start)
    depth = 0
    in_string = False
    escaped = False
    quote = ''
    for pos in range(start, len(text)):
        char = text[pos]
        if in_string:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == quote:
                in_string = False
        else:
            if char in ('"', "'"):
                in_string = True
                quote = char
            elif char == '[':
                depth += 1
            elif char == ']':
                depth -= 1
                if depth == 0:
                    return json.loads(text[start:pos + 1])
    return []


def restore_original_paperwork():
    papers = extract_embedded_paperwork()
    if not papers:
        print('No embedded paperwork found; migration skipped')
        return
    with app.connect() as conn:
        with conn.cursor() as cur:
            cur.execute('SELECT state, revision FROM app_state WHERE id=1 FOR UPDATE')
            row = cur.fetchone()
            if not row:
                return
            state = row['state']
            existing = {str(item.get('id')) for item in state.get('paperwork', [])}
            added = [item for item in papers if str(item.get('id')) not in existing]
            if not added:
                print('Original paperwork already present')
                return
            state.setdefault('paperwork', []).extend(added)
            state.setdefault('settings', {})['originalPaperworkRestored'] = True
            revision = int(row['revision']) + 1
            cur.execute(
                "UPDATE app_state SET state=%s::jsonb, revision=%s, updated_at=NOW(), updated_by='paperwork-migration' WHERE id=1",
                (json.dumps(state, ensure_ascii=False, separators=(',', ':')), revision),
            )
            cur.execute(
                "INSERT INTO server_audit(username,action,revision,details) VALUES(%s,%s,%s,%s::jsonb)",
                ('system', 'restore_original_paperwork', revision, json.dumps({'added': len(added)})),
            )
        conn.commit()
    print(f'Restored {len(added)} original paperwork records')


def harden_legacy_login(raw):
    guard = '<style id="secure-login-guard">#resetLogin,.login-note{display:none!important}#loginForm input[name="password"]{color:transparent!important;text-shadow:none!important}[data-complete-menu-upload]{display:none!important}</style>'
    if 'secure-login-guard' not in raw:
        raw = raw.replace('</head>', guard + '</head>', 1)
    return raw


RUNTIME_FILES = (
    '/command_de_cuisine_enhancements.js', '/kitchen_fixes_20260810.js', '/multi_page_menu_import.js', '/detailed_menu_recipes.js', '/reliable_menu_import.js', '/recipe_quality_upgrade.js', '/recipe_costing_fix.js', '/account_controls.js', '/logout_controls.js', '/manager_ai_temp_backfill.js', '/core_workflow_stability.js', '/history_truth_fix.js', '/temperature_records_module.js', '/temperature_history_reconcile.js', '/paper_import_undo.js', '/temperature_reset_guard.js',
    '/runtime_loader.js',
    '/delivery_patch.js', '/ai_server_patch.js', '/compliance_patch.js',
    '/login_cleanup_patch.js', '/recipe_management_patch.js', '/clockin_session_patch.js',
    '/ai_recipe_save_patch.js', '/ai_ideas_variety_patch.js', '/recipe_category_patch.js',
    '/menu_photo_complete_import_patch.js', '/kitchen_workflow_stable.js', '/prep_v2.js',
    '/global_kitchen_assistant_tabs.js', '/settings_pro_patch.js', '/tab_specific_forms.js',
    '/tab_spreadsheet_upgrade.js', '/analytics_tabs_upgrade.js', '/kitchen_dashboard.js',
)


class Handler(app.Handler):
    def do_GET(self):
        path = self.path.split('?', 1)[0]
        if path == '/':
            raw = (BASE_DIR / 'index.html').read_text(encoding='utf-8')
            scripts = (
                '<script src="/command_de_cuisine_enhancements.js?v=20260812c"></script>'
                '<script src="/kitchen_fixes_20260810.js?v=20260812c"></script>'
                '<script src="/multi_page_menu_import.js?v=20260812c"></script>'
                '<script src="/detailed_menu_recipes.js?v=20260812c"></script>'
                '<script src="/reliable_menu_import.js?v=20260812c"></script>'
                '<script src="/recipe_quality_upgrade.js?v=20260812c"></script>'
                '<script src="/recipe_costing_fix.js?v=20260812c"></script>'
                '<script src="/account_controls.js?v=20260812c"></script>'
                '<script src="/logout_controls.js?v=20260812c"></script>'
                '<script src="/manager_ai_temp_backfill.js?v=20260812c"></script>'
                '<script src="/core_workflow_stability.js?v=20260812c"></script>'
                '<script src="/history_truth_fix.js?v=20260812d"></script>'
                '<script src="/temperature_records_module.js?v=20260812f"></script>'
                '<script src="/temperature_history_reconcile.js?v=20260812a"></script>'
                '<script src="/temperature_gap_fill.js?v=20260812a"></script>'
                '<script src="/paper_import_undo.js?v=20260812a"></script>'
                '<script src="/temperature_reset_guard.js?v=20260813b"></script>'
            )
            if '/command_de_cuisine_enhancements.js' not in raw:
                before, found, after = raw.rpartition('</body>')
                if found:
                    raw = before + scripts + found + after
            else:
                extras = ''
                for script in (
                    'kitchen_fixes_20260810.js','multi_page_menu_import.js','detailed_menu_recipes.js','reliable_menu_import.js','recipe_quality_upgrade.js','recipe_costing_fix.js','account_controls.js','logout_controls.js','core_workflow_stability.js','history_truth_fix.js','temperature_records_module.js','temperature_history_reconcile.js','temperature_reset_guard.js'
                ):
                    if '/' + script not in raw:
                        version = '20260914-clean1' if script == 'temperature_reset_guard.js' else ('20260812a' if script in ('temperature_history_reconcile.js','paper_import_undo.js') else ('20260812f' if script == 'temperature_records_module.js' else ('20260812d' if script == 'history_truth_fix.js' else '20260812c')))
                        extras += f'<script src="/{script}?v={version}"></script>'
                if extras:
                    before, found, after = raw.rpartition('</body>')
                    if found:
                        raw = before + extras + found + after
            data = raw.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)
            return
        if path == '/api/session':
            auth_controls.send_session(self)
            return
        if path == '/api/export':
            auth_controls.send_export(self)
            return
        if path == '/api/temperature-readings':
            temperature_store.list_readings(self)
            return
        if path == '/api/drive/status':
            drive_storage.status(self)
            return
        if path in RUNTIME_FILES:
            data = (BASE_DIR / path.lstrip('/')).read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'application/javascript; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)
            return
        super().do_GET()

    def do_POST(self):
        path = self.path.split('?', 1)[0]
        if path == '/api/logout':
            logout_control.logout(self)
            return
        if path == '/api/openai/responses':
            ai_guard.handle(self)
            return
        if path == '/api/temperature-readings':
            try:
                payload = self.read_json()
            except Exception as exc:
                self.send_json({'error': str(exc)}, 400)
                return
            temperature_store.append_readings(self, payload)
            return
        if path == '/api/temperature-recovery/reset':
            try:
                payload = self.read_json()
            except Exception as exc:
                self.send_json({'error': str(exc)}, 400)
                return
            temperature_recovery_control.handle(self, payload)
            return
        if path == '/api/temperature-paper-import/undo':
            try:
                payload = self.read_json()
            except Exception as exc:
                self.send_json({'error': str(exc)}, 400)
                return
            paper_import_control.undo(self, payload)
            return
        if path in ('/api/setup-admin', '/api/login', '/api/password/change', '/api/users/create', '/api/users/manage', '/api/drive/upload', '/api/drive/backup'):
            try:
                payload = self.read_json()
            except Exception as exc:
                self.send_json({'error': str(exc)}, 400)
                return
            if path == '/api/setup-admin':
                auth_controls.bootstrap_admin(self, payload)
            elif path == '/api/login':
                auth_controls.login(self, payload)
            elif path == '/api/password/change':
                auth_controls.change_password(self, payload)
            elif path == '/api/users/create':
                auth_controls.create_user(self, payload)
            elif path == '/api/users/manage':
                auth_controls.manage_user(self, payload)
            elif path == '/api/drive/upload':
                drive_storage.upload_from_json(self, payload)
            else:
                drive_storage.backup_now(self)
            return
        super().do_POST()

    def do_PUT(self):
        if self.path.split('?', 1)[0] == '/api/state':
            try:
                payload = self.read_json()
            except Exception as exc:
                self.send_json({'error': str(exc)}, 400)
                return
            auth_controls.save_state(self, payload)
            return
        super().do_PUT()


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '10000'))
    print('Command de Cuisine listening on 0.0.0.0:%s' % port)
    ThreadingHTTPServer(('0.0.0.0', port), Handler).serve_forever()
