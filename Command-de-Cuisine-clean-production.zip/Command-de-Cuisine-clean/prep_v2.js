(function(){
  'use strict';
  function boot(){
    if(typeof state==='undefined'||typeof VIEWS==='undefined'||typeof page!=='function'||typeof save!=='function')return setTimeout(boot,200);
    if(window.__prepV2Active)return;window.__prepV2Active=true;
    if(!Array.isArray(state.prepLists))state.prepLists=[];

    const staffList=()=>Array.isArray(state.users)?state.users.filter(u=>u&&u.active!==false).map(u=>({name:String(u.name||u.username||'').trim(),username:String(u.username||'').trim().toLowerCase()})).filter(u=>u.name):[];
    const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const norm=v=>String(v||'').trim().toLowerCase().replace(/\s+/g,' ');
    const num=v=>{const n=Number(v);return Number.isFinite(n)?n:0;};
    const round=n=>Math.round((Number(n)||0)*100)/100;
    const today=()=>new Date().toISOString().slice(0,10);
    const uid=()=>`prep_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,7)}`;
    const menus=()=>Array.isArray(state.menus)?state.menus:[];
    const recipes=()=>Array.isArray(state.recipes)?state.recipes:[];
    const preps=()=>Array.isArray(state.prepLists)?state.prepLists:[];
    const menuFor=id=>menus().find(m=>String(m.id)===String(id));
    const recipesFor=m=>{const ids=(Array.isArray(m?.recipeIds)?m.recipeIds:[]).map(String);return recipes().filter(r=>ids.includes(String(r.id)));};
    const isManager=()=>{try{return String(me?.role||'').toLowerCase()==='manager';}catch(_){return false;}};
    let activeId=null;

    function liveStock(name,unit){
      return round((Array.isArray(state.stock)?state.stock:[]).filter(s=>norm(s.name)===norm(name)&&norm(s.unit)===norm(unit)).reduce((a,s)=>a+Math.max(0,num(s.qty)),0));
    }
    function calculate(menu,covers,existing){
      const ingredients=new Map(),oldJobs=new Map(((existing?.jobs)||[]).map(j=>[String(j.recipeId),j]));
      const jobs=recipesFor(menu).map(r=>{const old=oldJobs.get(String(r.id))||{};const base=Math.max(1,num(r.portions||r.yield)||10),factor=covers/base;(Array.isArray(r.ingredients)?r.ingredients:[]).forEach(i=>{if(!i||typeof i==='string'||!i.name)return;const q=num(i.qty??i.quantity),u=String(i.unit||'').trim();if(q<=0||!u)return;const key=norm(i.name)+'|'+norm(u),row=ingredients.get(key)||{key,name:String(i.name).trim(),unit:u,required:0};row.required=round(row.required+q*factor);ingredients.set(key,row);});return{recipeId:r.id,recipeName:r.name||'Recipe',portions:covers,assignedTo:old.assignedTo||'',completed:!!old.completed,notes:old.notes||''};});
      const oldStock=existing?.stock||{};
      const order=[...ingredients.values()].map(r=>{const inStock=Object.prototype.hasOwnProperty.call(oldStock,r.key)?Math.max(0,num(oldStock[r.key])):liveStock(r.name,r.unit);return{...r,inStock,toBuy:round(Math.max(0,r.required-inStock))};});
      return{jobs,order};
    }
    function buildRecord(existing){
      const menu=menuFor(document.getElementById('prepV2Menu')?.value);if(!menu)throw new Error('Select a saved menu');
      const covers=Math.max(1,Math.round(num(document.getElementById('prepV2Covers')?.value)||1));
      const date=document.getElementById('prepV2Date')?.value||today(),calc=calculate(menu,covers,existing||null);
      return{id:existing?.id||uid(),menuId:menu.id,menuName:menu.name||'Menu',date,covers,jobs:calc.jobs,order:calc.order,stock:Object.fromEntries(calc.order.map(r=>[r.key,r.inStock])),notes:existing?.notes||'',createdAt:existing?.createdAt||new Date().toISOString(),createdBy:existing?.createdBy||(typeof me!=='undefined'&&me?me.name:''),updatedAt:new Date().toISOString()};
    }
    function syncScreen(p){
      document.querySelectorAll('[data-prep-row]').forEach(row=>{const id=row.querySelector('[data-prep-job]')?.dataset.prepJob,job=p.jobs.find(j=>String(j.recipeId)===String(id));if(!job)return;job.assignedTo=row.querySelector('[data-prep-assignee]')?.value||'';job.completed=!!row.querySelector('[data-prep-complete]')?.checked;job.notes=row.querySelector('[data-prep-notes]')?.value||'';});
      document.querySelectorAll('[data-prep-stock]').forEach(x=>p.stock[x.dataset.prepStock]=Math.max(0,num(x.value)));
      p.order.forEach(r=>{r.inStock=Math.max(0,num(p.stock[r.key]));r.toBuy=round(Math.max(0,r.required-r.inStock));});p.notes=document.getElementById('prepV2Notes')?.value||'';p.updatedAt=new Date().toISOString();return p;
    }
    async function persist(p,msg){const i=preps().findIndex(x=>String(x.id)===String(p.id));if(i>=0)state.prepLists[i]=p;else state.prepLists.push(p);activeId=p.id;await Promise.resolve(save());if(typeof toast==='function')toast(msg||'Prep list saved','ok');}
    const staffOptions=s=>'<option value="">Unassigned</option>'+STAFF.map(x=>`<option ${x===s?'selected':''}>${esc(x)}</option>`).join('');

    function renderEditor(p){
      activeId=p.id;
      const jobs=(p.jobs||[]).map(j=>`<div class="row" data-prep-row><input data-prep-complete type="checkbox" ${j.completed?'checked':''}><input type="hidden" data-prep-job="${esc(j.recipeId)}"><div style="min-width:170px"><b>${esc(j.recipeName)}</b><br><small>${p.covers} portions</small></div><label>Assigned to<select data-prep-assignee>${staffOptions(j.assignedTo)}</select></label><label>Job note<input data-prep-notes value="${esc(j.notes||'')}" placeholder="Handover note"></label></div>`).join('');
      const order=(p.order||[]).map(r=>`<div class="row"><span></span><div><b>${esc(r.name)}</b><br><small>Required ${r.required} ${esc(r.unit)}</small></div><label>In stock<input data-prep-stock="${esc(r.key)}" type="number" min="0" step="0.01" value="${r.inStock}"></label><b data-prep-buy="${esc(r.key)}">Order ${r.toBuy} ${esc(r.unit)}</b></div>`).join('');
      const box=document.getElementById('prepV2Workspace');if(!box)return;box.innerHTML=`<div class="card mt"><div class="card-head"><div><h2>${esc(p.menuName)} · ${esc(p.date)}</h2><p class="muted">${p.covers} covers · ${(p.jobs||[]).filter(j=>j.completed).length}/${(p.jobs||[]).length} jobs complete</p></div><div class="btn-row"><button class="btn" id="prepV2Save">Save changes</button><button class="btn ghost" id="prepV2Print">Print</button><button class="btn ghost" id="prepV2Csv">Order CSV</button></div></div><div class="rows">${jobs||'<p>No prep jobs.</p>'}</div></div><div class="card mt"><h2>Order list</h2><p class="muted">Matching live stock is used automatically. Anything not found starts at zero.</p><div class="rows">${order||'<p>No order lines.</p>'}</div></div><div class="card mt"><label>Prep notes<textarea id="prepV2Notes" placeholder="Service notes, shortages, handover…">${esc(p.notes||'')}</textarea></label></div>`;
      const recalc=()=>document.querySelectorAll('[data-prep-stock]').forEach(input=>{const r=p.order.find(x=>x.key===input.dataset.prepStock);if(!r)return;r.inStock=Math.max(0,num(input.value));r.toBuy=round(Math.max(0,r.required-r.inStock));document.querySelectorAll('[data-prep-buy]').forEach(out=>{if(out.dataset.prepBuy===r.key)out.textContent=`Order ${r.toBuy} ${r.unit}`;});});
      document.querySelectorAll('[data-prep-stock]').forEach(x=>x.addEventListener('input',recalc));
      document.getElementById('prepV2Save').onclick=async()=>{syncScreen(p);await persist(p,'Prep list saved');renderPrep();openPrep(p.id);};
      document.getElementById('prepV2Print').onclick=()=>window.print();document.getElementById('prepV2Csv').onclick=()=>downloadCsv(syncScreen(p));
    }
    function downloadCsv(p){const rows=[['date','menu','covers','item','required','unit','in_stock','to_order'],...(p.order||[]).map(r=>[p.date,p.menuName,p.covers,r.name,r.required,r.unit,r.inStock,r.toBuy])],csv=rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n'),a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download=`prep-order-${p.date}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
    function openPrep(id){const stored=preps().find(x=>String(x.id)===String(id));if(!stored)return;activeId=stored.id;const menu=menuFor(stored.menuId);if(menu){const c=calculate(menu,stored.covers,stored);stored.jobs=c.jobs;stored.order=c.order;stored.stock=Object.fromEntries(c.order.map(r=>[r.key,r.inStock]));}const m=document.getElementById('prepV2Menu'),d=document.getElementById('prepV2Date'),c=document.getElementById('prepV2Covers');if(m)m.value=String(stored.menuId);if(d)d.value=stored.date;if(c)c.value=stored.covers;renderEditor(stored);}
    async function createPrep(){try{const p=buildRecord(null);await persist(p,'Prep list created');renderPrep();openPrep(p.id);}catch(e){if(typeof toast==='function')toast(e.message,'bad');}}
    async function deletePrep(id){if(!isManager())return typeof toast==='function'&&toast('Manager access required','bad');if(!confirm('Delete this saved prep list?'))return;state.prepLists=preps().filter(p=>String(p.id)!==String(id));if(String(activeId)===String(id))activeId=null;await Promise.resolve(save());renderPrep();}

    function renderPrep(){
      const opts=menus().map(m=>`<option value="${esc(m.id)}">${esc(m.name||'Menu')} (${recipesFor(m).length} recipes)</option>`).join('');
      const saved=preps().slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||String(b.updatedAt||'').localeCompare(String(a.updatedAt||''))).map(p=>`<div class="row"><span></span><div><b>${esc(p.menuName||'Prep')}</b><br><small>${esc(p.date||'')} · ${Number(p.covers||0)} covers · ${(p.jobs||[]).filter(j=>j.completed).length}/${(p.jobs||[]).length} complete</small></div><div class="btn-row"><button class="btn sm" data-open-prep="${esc(p.id)}">Open</button><button class="btn sm ghost" data-print-prep="${esc(p.id)}">Print</button>${isManager()?`<button class="btn sm bad" data-delete-prep="${esc(p.id)}">Delete</button>`:''}</div></div>`).join('');
      page('Prep Lists','Saved prep, assignments, completion and ordering from the selected menu.',`<div class="card"><h2>Create a prep list</h2><div class="form"><label>Saved menu<select id="prepV2Menu"><option value="">Select menu</option>${opts}</select></label><label>Prep date<input id="prepV2Date" type="date" value="${today()}"></label><label>Projected covers<input id="prepV2Covers" type="number" min="1" value="40"></label><button class="btn" id="prepV2Create">Build & save prep</button></div></div><div class="card mt"><h2>Saved prep lists</h2><div class="rows">${saved||'<p class="muted">No saved prep lists yet.</p>'}</div></div><div id="prepV2Workspace"></div>`);
      document.getElementById('prepV2Create').onclick=createPrep;document.querySelectorAll('[data-open-prep]').forEach(b=>b.onclick=()=>openPrep(b.dataset.openPrep));document.querySelectorAll('[data-print-prep]').forEach(b=>b.onclick=()=>{openPrep(b.dataset.printPrep);setTimeout(()=>window.print(),100);});document.querySelectorAll('[data-delete-prep]').forEach(b=>b.onclick=()=>deletePrep(b.dataset.deletePrep));if(activeId&&preps().some(p=>String(p.id)===String(activeId)))openPrep(activeId);
    }

    window.getPrepV2Context=()=>{const p=preps().find(x=>String(x.id)===String(activeId));return{savedPrepCount:preps().length,activePrep:p?{id:p.id,date:p.date,menu:p.menuName,covers:p.covers,notes:p.notes||'',jobs:(p.jobs||[]).map(j=>({recipe:j.recipeName,assignedTo:j.assignedTo||'',completed:!!j.completed,notes:j.notes||''})),order:(p.order||[]).map(r=>({item:r.name,required:r.required,unit:r.unit,inStock:r.inStock,toOrder:r.toBuy}))}:null};};
    window.applyPrepAICommand=async text=>{const p=preps().find(x=>String(x.id)===String(activeId));if(!p)return null;const q=String(text||'').trim();let m=q.match(/assign\s+(.+?)\s+to\s+(.+)$/i);if(m){const term=norm(m[1]),staffTerm=norm(m[2]),person=staffList().find(u=>norm(u.name)===staffTerm||norm(u.username)===staffTerm||norm(u.name).includes(staffTerm));if(!person)return`I could not find an active staff member matching “${m[2]}”.`;let n=0;p.jobs.forEach(j=>{if(norm(j.recipeName).includes(term)){j.assignedTo=person.name;n++;}});if(!n)return`I could not find a prep job matching “${m[1]}”.`;await persist(p,`${n} prep job${n===1?'':'s'} assigned to ${person.name}`);renderPrep();openPrep(p.id);return`Assigned ${n} matching prep job${n===1?'':'s'} to ${person.name}.`;}m=q.match(/mark\s+(.+?)\s+(?:as\s+)?(?:done|complete|completed)\b/i);if(m){const term=norm(m[1]);let n=0;p.jobs.forEach(j=>{if(norm(j.recipeName).includes(term)){j.completed=true;n++;}});if(!n)return`I could not find a prep job matching “${m[1]}”.`;await persist(p,`${n} prep job${n===1?'':'s'} completed`);renderPrep();openPrep(p.id);return`Marked ${n} matching prep job${n===1?'':'s'} complete.`;}return null;};

    VIEWS.prep=renderPrep;VIEWS.prepLists=renderPrep;window.renderPrepV2=renderPrep;
  }
  boot();
})();
